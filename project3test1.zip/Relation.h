//
// Created by Cole Sutton on 10/31/22.
//

#ifndef CS236PROJECT1_RELATION_H
#define CS236PROJECT1_RELATION_H

#include <set>
#include <vector>
#include <string>
#include <iostream>
#include "Header.h"
#include "Tuple.h"

using namespace std;

class Relation {
private:
    string name;
    Header columnNames;
    set<Tuple> tuples;
public:
    Relation() = default;
    Relation(string name, Header columnNames) {
        this->name = name;
        this->columnNames = columnNames;
    }

    string getName() {return name;}

    void addTuple(Tuple newTuple) {
        tuples.insert(newTuple);
    }

    void setTuples(const set<Tuple> &tuples) {Relation::tuples = tuples;};

    int tupleNum() {
        return tuples.size();
    }


    Relation select1 (int index, string value);

    Relation select2 (int index1, int index2);

    Relation project (vector<int> columnsToProject);

    Relation rename (vector<string> columnsToRename);

    void relationToString(){
        for(Tuple tuple: tuples) {
            cout << "  ";
            for (size_t i = 0; i < columnNames.getColumnNames().size(); i++) {
                //cout << "  ";
                cout << columnNames.getColumnNames().at(i) << "=" << tuple.getRowValues().at(i);
                if(i != columnNames.getColumnNames().size() - 1) {
                    cout << ", ";
                }
            }
            if(columnNames.getColumnNames().size() != 0) {
                cout << endl;
            }
        }
    }


};

#endif //CS236PROJECT1_RELATION_H
