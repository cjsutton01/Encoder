//
// Created by Cole Sutton on 10/31/22.
//

#ifndef CS236PROJECT1_TUPLE_H
#define CS236PROJECT1_TUPLE_H
#include <vector>

class Tuple {
private:
    std::vector<std::string> rowValues;
public:
    Tuple() = default;
    Tuple(std::vector<std::string> rowValues){
        this->rowValues = rowValues;
    }

    const std::vector<std::string> &getRowValues() const {
        return rowValues;
    }

    bool operator<(const Tuple &rhs) const {
        return rowValues < rhs.rowValues;
    }

};

#endif //CS236PROJECT1_TUPLE_H
