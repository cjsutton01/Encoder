//
// Created by Cole Sutton on 10/31/22.
//

#ifndef CS236PROJECT1_HEADER_H
#define CS236PROJECT1_HEADER_H
#include <vector>

class Header{
private:
    std::vector<std::string> columnNames;
public:
    Header() = default;
    Header(std::vector<std::string> columnNames) {
        this->columnNames = columnNames;
    }

    const std::vector<std::string> &getColumnNames() const {
        return columnNames;
    }

//    std::string printColumnNames() {
//        for (size_t i = 0; i < columnNames.size(); i++){
//            cout << columnNames.at(i);
//        }
//    }
};

#endif //CS236PROJECT1_HEADER_H
