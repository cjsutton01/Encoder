//
// Created by Cole Sutton on 11/1/22.
//
#include "Interpreter.h"
#include <vector>

using namespace std;

void Interpreter::runInterpreter() {
    interpretSchemes();
    interpretFacts();
    interpretQueries();
    //queriesToString();

}

void Interpreter::interpretSchemes() {
    for (unsigned int i = 0; i < myProgram.getSchemes().size(); i++){
        vector<string> columnNames;
        string name = myProgram.getSchemes().at(i)->getId(); //add name
        columnNames = (myProgram.getSchemes().at(i)->getParams()); //get vector of parameters(column names)
        Header myHeader(columnNames);
        Relation emptyRelation = Relation(name, myHeader);
        database.addRelation(emptyRelation);
    }
}

void Interpreter::interpretFacts() {
    for (unsigned int i = 0; i < myProgram.getFacts().size(); i++) {
        string tableName = myProgram.getFacts().at(i)->getId();
        Relation *newRelation = database.getRelationReference(tableName);
        newRelation->addTuple(Tuple(myProgram.getFacts().at(i)->getParams()));
    }
}

void Interpreter::interpretQueries() {
    vector<Predicate*> predicateQueries = myProgram.getQueries();
    for (unsigned int i = 0; i < predicateQueries.size(); i++) {
        //to string of unedited queries
        myProgram.getQueries().at(i)->PredicateToString();
        cout << "? ";

        map<string, int> seenBefore;
        vector<int> projectIndex;
        vector<string> renameValues;
        string tableName = predicateQueries.at(i)->getId();
        Relation r = database.getRelationCopy(tableName);
        vector<string> queryParams = predicateQueries.at(i)->getParams();
        for (unsigned int j = 0; j < queryParams.size(); j++){
            if(queryParams[j].at(0) == '\''){
                r = r.select1(j, queryParams[j]);
            }
            else if (seenBefore.count(queryParams[j]) == 1){
                r = r.select2(j , seenBefore[queryParams[j]]);
            }
            else{
                seenBefore.insert({queryParams[j], j});
                projectIndex.push_back(j);
                renameValues.push_back(queryParams[j]);
            }
        }
        r = r.project(projectIndex);

        r = r.rename(renameValues);

        if(r.tupleNum() == 0){
            cout << "No" << endl;
        }
        else {
            cout << "Yes(" << r.tupleNum() << ")" << endl;
            r.relationToString();
        }

        //pushback final edited queries
        //where do i make this vector?

    }
}

//void Interpreter::queriesToString() {
//    for (size_t i = 0; i < myProgram.getQueries().size(); i++){
//        myProgram.getQueries().at(i)->PredicateToString();
//        cout << "?" << endl;
//        //check finished tuple query size
//        // if 0 output no
//        // else run finished query to string
//        // where to make tostring?
//    }
//
//}


