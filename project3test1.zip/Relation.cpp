#include "Relation.h"

//code for select, project, rename

//relation select (int index, string value)
// relation newRelatrion(id, header)
//for (Tuple tuple: tuples)
// if tuple.getvalues[index] == value
//newrelation.addtuple(tuple)
// return new relation

//relation select 2(int index1, int index2)
// relation newRelatrion(id, header)
//for (Tuple tuple: tuples)
// if tuple.getvalues[index1] == tuple.getvalues[index2]
//newrelation.addtuple(tuple)
// return new relation
// relation project (

Relation Relation::select1(int index, string value) {
    Relation newRelation(value, Header());
    for (Tuple tuple: tuples){
        if(tuple.getRowValues()[index] == value){
            newRelation.addTuple(tuple);
        }
    }
    return newRelation;
}

Relation Relation::select2(int index1, int index2) {
    Relation newRelation;
    for (Tuple tuple: tuples){
        if(tuple.getRowValues()[index1] == tuple.getRowValues()[index2]){
            newRelation.addTuple(tuple);
        }
    }
    return newRelation;
}

Relation Relation::project(vector<int> columnsToProject) {
    vector<string>colNames = columnNames.getColumnNames();
    Relation newRelation(name, Header (colNames));
    //loop over every fact, loop over every parameter in projected fact and add to new relation
    for (Tuple newTuple: tuples){
        vector<string> values;
        for (int index: columnsToProject) {
            values.push_back(newTuple.getRowValues()[index]);
        }
        newRelation.addTuple(Tuple (values));
    }
    return newRelation;
}

Relation Relation::rename(vector<string> columnsToRename) {
    Relation newRelation(name, Header (columnsToRename));
    newRelation.setTuples(tuples);
    return newRelation;
}


